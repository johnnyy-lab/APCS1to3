# ==============================================================================
# 🧪 《PythAPCS123》單元 8-6：串列參照與淺拷貝 —— 官方智慧評分與日誌記錄器
# 存放位置：web/graders/grade_8_6.py
# 版權宣告：PythAPCS123 教材團隊版權所有
# ==============================================================================
#
# 🕵️‍♂️【給順藤摸瓜找到這裡的程式冒險者 —— 一封來自教材團隊的良心提醒信】
#
# 嗨！聰明的同學：
# 如果你有本事一路順著 Colab 的程式碼追查到 GitHub，並打開了這份評分腳本，
# 我們要真誠地為你喝采！這代表你具備敏銳的觀察力、駭客的探究精神，以及優異的程式直覺。
# 這種「打破砂鍋問到底、想搞懂系統底層怎麼運作」的好奇心，正是優秀工程師最珍貴的特質。
#
# 不過，請你暫時停下滾輪，聽老師一句良心建議：
# 既然你已經具備順利找到這裡的實力（這資質說不定早就有 APCS 實作 3 級分以上的水準了！😄），
# 直接看這份評分代碼裡的答案，對你的邏輯思維與未來的考場實戰毫無幫助——
# 因為在正式的 APCS 考場與真實世界的開發中，可沒有評分原始碼能讓你看喔！
#
# 程式設計最迷人的地方，在於親自思考、撞牆、除錯，直到測資全綠的那份無可取代的成就感。
#
# 何不現在就帥氣地關掉這個視窗，回到 Colab 筆記本，靠自己的雙手把每一題寫出來？
# 真正的程式大師，靠實力讓系統亮起綠燈！期待在未來的 APCS 考場與競賽舞台看見你的精彩表現！🚀
# ==============================================================================

import sys
import os
import json
import urllib.request
import urllib.parse
import unicodedata
from datetime import datetime, timezone, timedelta
import logging

# 抑制 google_auth_httplib2 的 timeout 內部警告
logging.getLogger("google_auth_httplib2").setLevel(logging.ERROR)

# 確保輸出支援 UTF-8
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LOG_WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbyXv4s0qihj03Lg3oFop3HffQNYob-M9OxxJVPX04LxeBY22IvYcFh8v2hTZgWsX5InKQ/exec"
# 版次 token。Apps Script 用它確認這次送出的是現行契約。
GRADER_VERSION = "2026-10-19"
NOTEBOOK_FILE = "PythAPCS123_8-6_list_reference_and_shallow_copy.ipynb"

def _disp_width(text):
    """計算終端顯示寬度（全形/CJK 字元佔 2 欄）。

    刻意不用 sum() 等內建：學員答案變數可能取名 sum、max。
    直接執行腳本時答案與評分器在同一個全域，呼叫內建會被遮蔽。"""
    total = 0
    for ch in text:
        if unicodedata.east_asian_width(ch) in ("W", "F"):
            total += 2
        else:
            total += 1
    return total


def _pad(text, width):
    """以顯示寬度為基準補齊空白，讓全形題名在終端也能對齊。"""
    gap = width - _disp_width(text)
    if gap > 0:
        return text + " " * gap
    return text


def _student_value(env, names):
    """各題學生實際值，截斷到 80 字元，方便分辨 7 與 7.0。"""
    parts = []
    for name in names:
        if name in env:
            parts.append(f"{name}={env.get(name)!r}")
        else:
            parts.append(f"{name}=缺")
    return ", ".join(parts)[:80]

def _student_env(env=None):
    """學員變數所在的命名空間。

    Cell B 隔離載入時讀 __STUDENT_ENV__。直接執行腳本，或測試把答案
    放在同一個全域時，改讀 globals()。"""
    if isinstance(env, dict):
        return env
    snapshot = globals().get("__STUDENT_ENV__")
    if isinstance(snapshot, dict):
        return snapshot
    return globals()


def fetch_google_account_info(env=None):
    """讀取 Cell B 已完成的身分認證結果（Google Email 與暱稱）。

    鐵律：Google 認證流程只在 Cell B 執行一次，評分腳本僅讀取結果，
    絕不在此重跑 authenticate_user()，避免二次授權視窗與雙份維護飄移。"""
    env = _student_env(env)
    google_email = str(env.get("google_email") or os.environ.get("GOOGLE_EMAIL") or "").strip() or None
    google_name = str(env.get("google_name") or os.environ.get("GOOGLE_NAME") or "").strip() or None
    return google_email, google_name


def auto_grade_unit_8_6(env=None):
    env = _student_env(env)
    total_score = 0
    max_score = 100

    # 1. 讀取學生姓名與學號座號（分開獨立欄位，支援全域變數與環境變數）
    declared_name = str(env.get("student_name", "")).strip() or os.environ.get("STUDENT_NAME", "").strip() or "自學冒險者"
    declared_id = str(env.get("student_id", "")).strip() or os.environ.get("STUDENT_ID", "").strip() or "無座號"

    # 2. 自動嘗試獲取 Google 帳號 Email 與 Google 暱稱
    google_email, google_name = fetch_google_account_info(env)

    # 3. 整合身分識別欄位（區分 Colab 雲端認證與本機免登入自評）
    is_colab = False
    try:
        import google.colab
        is_colab = True
    except ImportError:
        is_colab = False

    if google_email:
        final_email = google_email
        final_google_name = google_name if google_name else declared_name
        combined_display_name = f"{declared_name} (Google: {final_google_name})"
    elif not is_colab:
        final_email = "本機"
        final_google_name = "本機"
        combined_display_name = f"{declared_name} (本機)"
    else:
        fallback_email = str(env.get("student_email", "")).strip()
        final_email = fallback_email if fallback_email and fallback_email != "student@example.com" else "未綁定 Google"
        final_google_name = "訪客"
        combined_display_name = declared_name

    tw_tz = timezone(timedelta(hours=8))
    timestamp_str = datetime.now(tw_tz).strftime("%Y-%m-%d %H:%M:%S")

    input_history = env.get("_ih", env.get("In", []))
    history_str = "\n".join(input_history) if isinstance(input_history, list) else ""
    history_clean = history_str.replace(" ", "")

    test_cases = [
        # ----------------------------------------------------------------------
        # 8-6-1 變數賦值的大陷阱：b = a 只是共用同一張標籤 (共 20 分)
        # ----------------------------------------------------------------------
        ("8-6-1", "填空題", "串列參照賦值共用 (shrd_crt = crt)", 6, (),
         lambda g: (
             (True, "shrd_crt = crt 參照賦值正確！")
             if ("shrd_crt=crt" in history_clean or "shrd_crt = crt" in history_str) and
                ("滑鼠" in history_str)
             else (False, "請在 8-6-1 填空題空格將 crt 賦值給 shrd_crt！")
         )),

        ("8-6-1", "練習題", "別名共用污染首尾修改印出 orig_list (alias_list = orig_list 修改輸出)", 9, (),
         lambda g: (
             (True, "alias_list = orig_list 別名共用污染驗證輸出正確！")
             if (("alias_list = orig_list" in history_str or "alias_list=orig_list" in history_clean) and
                 ("[100, 2, 99]" in history_str or "[100, 6, 7, 99]" in history_str or ("alias_list[0]" in history_clean and "alias_list[-1]" in history_clean)))
             else (False, "請設定 alias_list = orig_list，修改 alias_list 的首尾元素並印出受到連動影響的 orig_list！")
         )),

        ("8-6-1", "挑戰題", "被污染的遊戲存檔情境模擬 (backup = player_stats)", 5, (),
         lambda g: (
             (True, "遊戲存檔共用參照污染情境模擬正確！")
             if ("player_stats" in history_str and "backup" in history_str and "-= 40" in history_str) or
                ("[60, 50]" in history_str)
             else (False, "請模擬 backup = player_stats，扣除血量後輸出被污染的 backup！")
         )),

        # ----------------------------------------------------------------------
        # 8-6-2 身分證驗證：id() 函式與 is 運算子 (共 20 分)
        # ----------------------------------------------------------------------
        ("8-6-2", "填空題", "is 運算子與 == 運算子身分對決填空", 6, (),
         lambda g: (
             (True, "== 內容比對與 is 物件身分同一性填空正確！")
             if ("list1 == list2" in history_str or "list1==list2" in history_clean) and
                ("list1 is list2" in history_str or "list1islist2" in history_clean)
             else (False, "請在 8-6-2 填空題依序填入 == 與 is 運算子！")
         )),

        ("8-6-2", "練習題", "同一物件性判定印出 (p is q 為 True, p is r086 為 False)", 9, (),
         lambda g: (
             (True, "p is q (True) 與 p is r086 (False) 印出正確！")
             if ("p is q" in history_str and "p is r086" in history_str) or
                ("True\nFalse" in history_str)
             else (False, "請分別印出 p is q 與 p is r086 的布林值結果！")
         )),

        ("8-6-2", "挑戰題", "別名與獨立拷貝三變數檢驗 (alias is True, clone is False)", 5, (),
         lambda g: (
             (True, "alias (同一物件) 與 clone (內容相同身分相異) 檢驗成功！")
             if ("items is alias" in history_str or "items is clone" in history_str or "clone" in history_str)
             else (False, "請宣告 alias 與 clone，驗證 items is alias 與 items == clone！")
         )),

        # ----------------------------------------------------------------------
        # 8-6-3 製作真正的獨立副本：copy() 方法 (共 20 分)
        # ----------------------------------------------------------------------
        ("8-6-3", "填空題", "呼叫 copy() 方法建立獨立副本 (safe_cart)", 6, ("safe_cart", "orgn_crt"),
         lambda g: (
             (True, "使用 .copy() 建立獨立副本成功！")
             if ("orgn_crt.copy()" in history_clean) or
                (g.get("safe_cart") == ["牛奶", "麵包", "蘋果"] and "糖果" in g.get("orgn_crt", []))
             else (False, "請在 8-6-3 填空題空格填入方法名稱 copy！")
         )),

        ("8-6-3", "練習題", "獨立副本調分輸出 (sc086.copy() 加分獨立不連動)", 9, (),
         lambda g: (
             (True, "copy() 調分副本與原成績單雙軌輸出正確！")
             if ("sc086.copy()" in history_clean and ("+= 10" in history_str or "+10" in history_clean)) or
                ("[70, 80, 90]\n[80, 90, 100]" in history_str or "[50, 60]\n[60, 70]" in history_str)
             else (False, "請使用 copy() 建立副本並為副本加 10 分，依序印出兩份成績！")
         )),

        ("8-6-3", "挑戰題", "商品調價模擬器 (promo_prices = original_prices.copy())", 5, (),
         lambda g: (
             (True, "獨立調價副本建構與八折計算正確！")
             if ("original_prices.copy()" in history_clean and ("* 8 // 10" in history_str or "*8//10" in history_clean)) or
                ("[100, 200, 320]" in history_str)
             else (False, "請建立 copy() 副本 promo_prices 並將 > 200 商品打八折輸出！")
         )),

        # ----------------------------------------------------------------------
        # 8-6-4 切片複製經典技法：b = a[:] (共 20 分)
        # ----------------------------------------------------------------------
        ("8-6-4", "填空題", "全範圍切片複製語法 words[:]", 6, ("new_words", "words"),
         lambda g: (
             (True, "全範圍切片 words[:] 複製完全正確！")
             if ("words[:]" in history_clean) or
                (g.get("new_words") == ["PYTHON", "rocks"] and g.get("words") == ["python", "rocks"])
             else (False, "請在 8-6-4 填空題中括號內填入冒號 : 完成全範圍切片複製！")
         )),

        ("8-6-4", "練習題", "切片複製獨立性與 pop 移除印出長度", 9, (),
         lambda g: (
             (True, "ns086[:] 切片副本與 pop() 長度驗證正確！")
             if ("ns086[:]" in history_clean and "fltr_ns.pop()" in history_clean) or
                ("長度: 4" in history_str and "長度: 3" in history_str)
             else (False, "請使用 ns086[:] 複製副本，從副本 pop 末位並印出兩者內容與長度！")
         )),

        ("8-6-4", "挑戰題", "參照、copy() 與 [:] 三重同一性驗證", 5, (),
         lambda g: (
             (True, "ref_alias、copy() 與 [:] 三重身分驗證完整！")
             if ("ref_src is ref_alias" in history_str and "ref_src is ref_copy" in history_str and "ref_src is ref_slice" in history_str) or
                ("True\nFalse\nFalse" in history_str)
             else (False, "請分別輸出 ref_src is ref_alias, ref_src is ref_copy, ref_src is ref_slice 的布林值結果！")
         )),

        # ----------------------------------------------------------------------
        # 8-6-5 淺拷貝（Shallow Copy）的核心本質與防禦實踐 (共 20 分)
        # ----------------------------------------------------------------------
        ("8-6-5", "填空題", "list() 型態建構函式淺拷貝 (indp_tgs)", 6, ("indp_tgs", "orgn_tgs"),
         lambda g: (
             (True, "使用 list(orgn_tgs) 建構式拷貝成功！")
             if ("list(orgn_tgs)" in history_clean) or
                ("apcs" in g.get("indp_tgs", []) and "apcs" not in g.get("orgn_tgs", []))
             else (False, "請在 8-6-5 填空題空格填入型態名稱 list！")
         )),

        ("8-6-5", "練習題", "副本清空測試 (test_stock.clear() 原始長度不受影響)", 9, (),
         lambda g: (
             (True, "副本清空與原庫存長度保留輸出正確！")
             if ("test_stock.clear()" in history_clean or "test_stock[:] = []" in history_str) and
                ("原始長度:" in history_str and "副本長度:" in history_str) or
                ("原始長度: 3\n副本長度: 0" in history_str or "原始長度: 1\n副本長度: 0" in history_str)
             else (False, "請以 copy() 建立副本並清空，輸出原始長度與副本長度！")
         )),

        ("8-6-5", "挑戰題", "模擬資料防護系統 (加獎勵積分 100 原總和保持 60)", 5, (),
         lambda g: (
             (True, "安全副本資料防護與總和比對正確！")
             if ("working_points" in history_str and ".copy(" in history_str and "sum(" in history_str) or
                ("60" in history_str and "160" in history_str)
             else (False, "請在安全副本中加 100 分，驗證原串列總和仍保持為 60！")
         ))
    ]

    pass_count = 0
    item_results = []
    item_outputs = []

    for uid, qtype, name, pts, watch, checker in test_cases:
        try:
            ok, msg = checker(env)
        except Exception:
            ok, msg = False, "執行檢驗時發生異常，請確認程式碼是否可正常執行"

        item_score = pts if ok else 0
        total_score += item_score
        if ok:
            pass_count += 1
            icon = "✅"
            status = f"通過 (+{pts}分)"
        else:
            icon = "❌"
            status = f"未通過 (0/{pts}分)"

        out_lines = [f"{icon} [{uid} {qtype}] {_pad(name, 44)} ➔ {status}"]
        if not ok:
            out_lines.append(f"   💡 提示：{msg}")
        item_outputs.append(out_lines)

        item_results.append({
            "uid": uid,
            "type": qtype,
            "name": name,
            "passed": ok,
            "score": item_score,
            "max_score": pts,
            "message": msg,
            "student_value": _student_value(env, watch)
        })

    if total_score >= 90:
        badge = '🏆 傳奇大師（金牌徽章 🥇）—— 徹底精通串列參照共用、id() 記憶體門牌、is 與 == 對決、copy() 與 [:] 淺拷貝，防禦工程宗師！'
    elif total_score >= 80:
        badge = '🥈 卓越冒險者（銀牌徽章 🥈）—— 表現優異，串列參照大陷阱與獨立副本原理掌握精準！'
    elif total_score >= 60:
        badge = '🥉 扎根學徒（銅牌徽章 🥉）—— 基礎已建立，請針對紅叉題目微調 is 運算子與 copy() 呼叫！'
    else:
        badge = '🌱 潛力新星 —— 請確認上方各題目是否都已按下播放鍵 ▶ 執行作答喔！'

    print("=" * 72)
    print(" 📊 《PythAPCS123》單元 8-6：串列參照與淺拷貝 —— 自動評分報告")
    print("=" * 72)
    print(f" 📈 本單元實作測驗總得分：{total_score} / {max_score} 分（通過題數：{pass_count} / {len(test_cases)} 題）")
    print(f" 🎖️ 獲得榮譽等級：{badge}")
    print("=" * 72)
    print(f" 👤 學員姓名：{declared_name}")
    print(f" 🆔 學號座號：{declared_id}")
    if google_email:
        print(f" 🔑 Google 帳號認證：{google_email}（暱稱：{final_google_name}）")
    elif not is_colab:
        print(f" 💻 執行環境：本機環境（免登入自評）")
    else:
        print(f" 📧 登記信箱：{final_email}")
    print(f" ⏰ 送交時間：{timestamp_str}")
    print("=" * 72)
    print(" 📝 題目作答細項檢驗：")
    for lines in item_outputs:
        for line in lines:
            print(line)
    print("=" * 72)

    # 試算表姓名、學號用學生輸入原值。暱稱與 email 在本機填「本機測試」。
    if google_email:
        sheet_google_name = google_name if google_name else declared_name
        sheet_google_email = google_email
    elif not is_colab:
        sheet_google_name = "本機測試"
        sheet_google_email = "本機測試"
    else:
        sheet_google_name = "未認證"
        sheet_google_email = "未認證"

    score_fingerprint = ",".join(
        f"{item['uid']}:{item['type']}:{'1' if item['passed'] else '0'}"
        for item in item_results
    )

    # --------------------------------------------------------------------------
    # 📡 雲端後台成績記錄（Google Apps Script 試算表 Webhook）
    # 欄位拆開送出。相同成績是否寫入由 Apps Script 判斷，這裡只讀回應。
    # 鐵律：絕不產生任何本地日誌暫存檔。
    # --------------------------------------------------------------------------
    log_data = {
        "unit": "8-6",
        "unit_title": "串列參照與淺拷貝",
        "declared_name": declared_name,
        "declared_id": declared_id,
        "google_name": sheet_google_name,
        "google_email": sheet_google_email,
        "student_name": declared_name,
        "student_id": declared_id,
        "name": declared_name,
        "id": declared_id,
        "student_email": sheet_google_email,
        "email": sheet_google_email,
        "timestamp": timestamp_str,
        "total_score": total_score,
        "max_score": max_score,
        "pass_count": pass_count,
        "total_count": len(test_cases),
        "badge": badge,
        "details": item_results,
        "grader_version": GRADER_VERSION,
        "grader_source": os.environ.get("GRADER_SOURCE", "").strip() or "web/graders/grade_8_6.py",
        "notebook_file": NOTEBOOK_FILE,
        "score_fingerprint": score_fingerprint
    }

    if LOG_WEBHOOK_URL:
        try:
            req_data = json.dumps(log_data, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(
                LOG_WEBHOOK_URL,
                data=req_data,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                raw_body = response.read().decode("utf-8", errors="replace").strip()
            status = ""
            if raw_body:
                try:
                    payload = json.loads(raw_body)
                    if isinstance(payload, dict):
                        status = str(payload.get("status", "")).strip().lower()
                except json.JSONDecodeError:
                    status = ""
            if status == "duplicate":
                print("📡 [雲端回報] 成績與上次相同，未重複登錄（本機成績仍有效）。\n")
            else:
                print("📡 [雲端回報] 成績已成功上傳並登錄至授課試算表！\n")
        except Exception:
            # 離線測試或連線逾時溫和提示，絕不噴出紅色例外
            if not is_colab:
                print("📡 [本機模式] 成績已於本機評分完成（雲端試算表未連線）。\n")
            else:
                print("📡 [離線模式] 暫時無法連線至雲端試算表，但本機評分已完成。\n")

    if total_score < 100:
        print("\n💡 小技巧：若有題目顯示 ❌ 未通過，請回到上方對應題目的儲存格修改程式碼，")
        print("   並務必重新點擊該題的『▶ 播放鍵』執行，再回來執行此評分儲存格就可以刷新成績與紀錄囉！")
        print("=" * 72)


# 執行評分
auto_grade_unit_8_6()
