# ==============================================================================
# 🧪 《PythAPCS123》單元 9-9：網格防護與動態模擬：哨兵加框與雙矩陣快照（APCS f313 專題） —— 官方智慧評分與日誌記錄器
# 存放位置：web/graders/grade_9_9.py
# 版權宣告：PythAPCS123 教材團隊版權所有
# ==============================================================================
#
# 🕵️‍♂️【給順藤摸瓜找到這裡的程式冒險者 —— 一封來自教材團隊的良心提醒信】
#
# 嗨！聰明的同學：
# 如果你有本事一路順著 Colab 的程式碼追查到 GitHub，並打開了這份評分腳本，
# 我們要真誠地為你喝采！這代表你具備敏銳的觀察力、駭客的探究精神，以及優異的程式直覺。
# 這種「打破砂鍋問到底、想搞懂系統底層怎麼運作」的好奇心，正是優秀工程師最珍貴的特質。
#
# 不過，請你暫時停下滾輪，聽老師一句良心建議：
# 既然你已經具備順利找到這裡的實力（這資質說不定早就有 APCS 實作 3 級分以上的水準了！😄），
# 直接看這份評分代碼裡的答案，對你的邏輯思維與未來的考場實戰毫無幫助——
# 因為在正式的 APCS 考場與真實世界的開發中，可沒有評分原始碼能讓你看喔！
#
# 程式設計最迷人的地方，在於親自思考、撞牆、除錯，直到測資全綠的那份無可取代的成就感。
#
# 何不現在就帥氣地關掉這個視窗，回到 Colab 筆記本，靠自己的雙手把每一題寫出來？
# 真正的程式大師，靠實力讓系統亮起綠燈！期待在未來的 APCS 考場與競賽舞台看見你的精彩表現！🚀
# ==============================================================================

import sys
import os
import json
import urllib.request
import urllib.parse
import unicodedata
from datetime import datetime, timezone, timedelta
import logging

# 抑制 google_auth_httplib2 的 timeout 內部警告
logging.getLogger("google_auth_httplib2").setLevel(logging.ERROR)

# 確保輸出支援 UTF-8
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

LOG_WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbyXv4s0qihj03Lg3oFop3HffQNYob-M9OxxJVPX04LxeBY22IvYcFh8v2hTZgWsX5InKQ/exec"
# 版次 token。Apps Script 用它確認這次送出的是現行契約。
GRADER_VERSION = "2026-10-19"
NOTEBOOK_FILE = "PythAPCS123_9-9_grid_padding_and_simulation_apcs_f313.ipynb"

def _disp_width(text):
    """計算終端顯示寬度（全形/CJK 字元佔 2 欄）。

    刻意不用 sum() 等內建：學員答案變數可能取名 sum、max。
    直接執行腳本時答案與評分器在同一個全域，呼叫內建會被遮蔽。"""
    total = 0
    for ch in text:
        if unicodedata.east_asian_width(ch) in ("W", "F"):
            total += 2
        else:
            total += 1
    return total


def _pad(text, width):
    """以顯示寬度為基準補齊空白，讓全形題名在終端也能對齊。"""
    gap = width - _disp_width(text)
    if gap > 0:
        return text + " " * gap
    return text


def _student_value(env, names):
    """各題學生實際值，截斷到 80 字元，方便分辨 7 與 7.0。"""
    parts = []
    for name in names:
        if name in env:
            parts.append(f"{name}={env.get(name)!r}")
        else:
            parts.append(f"{name}=缺")
    return ", ".join(parts)[:80]

def _student_env(env=None):
    """學員變數所在的命名空間。

    Cell B 隔離載入時讀 __STUDENT_ENV__。直接執行腳本，或測試把答案
    放在同一個全域時，改讀 globals()。"""
    if isinstance(env, dict):
        return env
    snapshot = globals().get("__STUDENT_ENV__")
    if isinstance(snapshot, dict):
        return snapshot
    return globals()


def fetch_google_account_info(env=None):
    """讀取 Cell B 已完成的身分認證結果（Google Email 與暱稱）。

    鐵律：Google 認證流程只在 Cell B 執行一次，評分腳本僅讀取結果，
    絕不在此重跑 authenticate_user()，避免二次授權視窗與雙份維護飄移。"""
    env = _student_env(env)
    google_email = str(env.get("google_email") or os.environ.get("GOOGLE_EMAIL") or "").strip() or None
    google_name = str(env.get("google_name") or os.environ.get("GOOGLE_NAME") or "").strip() or None
    return google_email, google_name


def auto_grade_unit_9_9(env=None):
    env = _student_env(env)
    total_score = 0
    max_score = 100

    # 1. 讀取學生姓名與學號座號（分開獨立欄位，支援全域變數與環境變數）
    declared_name = str(env.get("student_name", "")).strip() or os.environ.get("STUDENT_NAME", "").strip() or "自學冒險者"
    declared_id = str(env.get("student_id", "")).strip() or os.environ.get("STUDENT_ID", "").strip() or "無座號"

    # 2. 自動嘗試獲取 Google 帳號 Email 與 Google 暱稱
    google_email, google_name = fetch_google_account_info(env)

    # 3. 整合身分識別欄位（區分 Colab 雲端認證與本機免登入自評）
    is_colab = False
    try:
        import google.colab
        is_colab = True
    except ImportError:
        is_colab = False

    if google_email:
        final_email = google_email
        final_google_name = google_name if google_name else declared_name
        combined_display_name = f"{declared_name} (Google: {final_google_name})"
    elif not is_colab:
        final_email = "本機"
        final_google_name = "本機"
        combined_display_name = f"{declared_name} (本機)"
    else:
        fallback_email = str(env.get("student_email", "")).strip()
        final_email = fallback_email if fallback_email and fallback_email != "student@example.com" else "未綁定 Google"
        final_google_name = "訪客"
        combined_display_name = declared_name

    tw_tz = timezone(timedelta(hours=8))
    timestamp_str = datetime.now(tw_tz).strftime("%Y-%m-%d %H:%M:%S")

    input_history = env.get("_ih", env.get("In", []))
    history_str = "\n".join(input_history) if isinstance(input_history, list) else ""
    history_clean = history_str.replace(" ", "")

    test_cases = [
        # ----------------------------------------------------------------------
        # 9-9-1 哨兵加框法概念 (Grid Padding) (共 16 分: 5 + 6 + 5)
        # ----------------------------------------------------------------------
        ("9-9-1", "填空題", "哨兵加框尺寸 [[-1] * (C099 + 2) for _ in range(R099 + 2)]", 5, (),
         lambda g: (
             (True, "哨兵加框尺寸生成式填空正確！")
             if ("C099 + 2" in history_str and "R099 + 2" in history_str) or
                ("C099+2" in history_clean and "R099+2" in history_clean)
             else (False, "請在 9-9-1 填空題填入加框尺寸 C099 + 2 與 R099 + 2！")
         )),

        ("9-9-1", "練習題", "將原網格拷貝進加框矩陣中心 [1..R099][1..C099]", 6, (),
         lambda g: (
             (True, "原網格置入加框中心正確！")
             if ("pddd[r + 1][c + 1] = gd099[r][c]" in history_str or "pddd[r+1][c+1]=gd099[r][c]" in history_clean or
                 "pddd[r+1][c+1]" in history_clean)
             else (False, "請將 gd099[r][c] 填入 pddd[r + 1][c + 1] 中心區域！")
         )),

        ("9-9-1", "挑戰題", "加框矩陣邊界驗證 (四周全為 -1)", 5, (),
         lambda g: (
             (True, "加框矩陣外圍守衛驗證正確！")
             if ("-1" in history_str and "pddd099" in history_str)
             else (False, "請驗證 pddd099 最外層一圈全為 -1 哨兵值！")
         )),

        # ----------------------------------------------------------------------
        # 9-9-2 加框矩陣與原矩陣座標對應 (r + 1, c + 1) (共 17 分: 5 + 6 + 6)
        # ----------------------------------------------------------------------
        ("9-9-2", "填空題", "加框座標對應填空 padded[r + 1][c + 1]", 5, (),
         lambda g: (
             (True, "加框座標對應填空正確！")
             if ("r + 1" in history_str and "c + 1" in history_str) or ("r+1" in history_clean and "c+1" in history_clean)
             else (False, "請在 9-9-2 填空題填入 r + 1 與 c + 1！")
         )),

        ("9-9-2", "練習題", "在加框網格中免邊界判斷直接存取四相鄰點", 6, (),
         lambda g: (
             (True, "加框免邊界四相鄰存取正確！")
             if ("pddd2[r][c+1]" in history_clean or "pddd2[r+2][c+1]" in history_clean or "pddd2" in history_str)
             else (False, "請直接存取 pddd2 上下左右四格，省略邊界 if 判斷！")
         )),

        ("9-9-2", "挑戰題", "加框網格還原回原始矩陣尺寸", 6, (),
         lambda g: (
             (True, "加框網格還原提取正確！")
             if ("padded[r][1:-1]" in history_clean or "range(1, R099 + 1)" in history_str)
             else (False, "請將中心 [1..R099][1..C099] 資料取出還原回原網格！")
         )),

        # ----------------------------------------------------------------------
        # 9-9-3 原地修改「資料污染」致命陷阱與快照防禦 (共 17 分: 5 + 6 + 6)
        # ----------------------------------------------------------------------
        ("9-9-3", "填空題", "快照建立 snapshot = [row.copy() for row in gd62]", 5, (),
         lambda g: (
             (True, "快照副本語法填空正確！")
             if ("row.copy()" in history_clean or "row[:]" in history_clean)
             else (False, "請在 9-9-3 填空題填入 row.copy() 或 row[:] 建立乾淨快照！")
         )),

        ("9-9-3", "練習題", "對比實驗：原地修改資料污染 vs 快照同步結算", 6, (),
         lambda g: (
             (True, "快照對比實驗實作正確！")
             if ("snps" in history_str or "copy" in history_str) and "grid" in history_str
             else (False, "請使用快照讀取舊狀態，避免原地修改互相污染！")
         )),

        ("9-9-3", "挑戰題", "驗證多細胞狀態同時同步切換", 6, (),
         lambda g: (
             (True, "多格同步更新切換正確！")
             if ("new_grid" in history_str or "next_grid" in history_str or "snapshot" in history_str)
             else (False, "請建立 new_grid 結算下一回合狀態並整體替換！")
         )),

        # ----------------------------------------------------------------------
        # 9-9-4 增減量矩陣架構 (Delta Grid) (共 17 分: 5 + 6 + 6)
        # ----------------------------------------------------------------------
        ("9-9-4", "填空題", "增減量矩陣初始化 delta = [[0] * C099 for _ in range(R099)]", 5, (),
         lambda g: (
             (True, "delta 矩陣初始化填空正確！")
             if ("delta = [[0] * C099 for _ in range(R099)]" in history_str or "delta=[[0]*Cfor_inrange(R099)]" in history_clean or
                 "[[0] * C099 for _ in range(R099)]" in history_str)
             else (False, "請在 9-9-4 填空題填入 delta 增減量矩陣初始化語法！")
         )),

        ("9-9-4", "練習題", "記錄遷出量 delta[r][c] -= out 與遷入量 += in", 6, (),
         lambda g: (
             (True, "delta 增減量記錄正確！")
             if ("delta" in history_str and "-=" in history_str and "+=" in history_str)
             else (False, "請在 delta 矩陣中分別累加遷入量與扣減遷出量！")
         )),

        ("9-9-4", "挑戰題", "驗證全地圖 delta 總和恆等於 0 (守恆定律)", 6, (),
         lambda g: (
             (True, "delta 守恆總和為 0 驗證正確！")
             if ("sum(sum(row) for row in delta)" in history_str or "sum" in history_str and "delta" in history_str and "== 0" in history_str)
             else (False, "請計算 delta 全圖總和並驗證其值為 0！")
         )),

        # ----------------------------------------------------------------------
        # 9-9-5 單回合相鄰擴散與增減量結算 (共 17 分: 5 + 6 + 6)
        # ----------------------------------------------------------------------
        ("9-9-5", "填空題", "擴散份量整數除法 give = pop_val // k", 5, (),
         lambda g: (
             (True, "擴散除法 give = pop_val // k 填空正確！")
             if ("pop_val // k" in history_str or "pop_val//k" in history_clean)
             else (False, "請在 9-9-5 填空題填入 pop_val // k！")
         )),

        ("9-9-5", "練習題", "單回合相鄰擴散與 gd65[r][c] += dlt2[r][c] 結算", 6, (),
         lambda g: (
             (True, "單回合擴散結算正確！")
             if ("gd65[r][c] += dlt2[r][c]" in history_str or "gd65[r][c]+=dlt2[r][c]" in history_clean or
                 "dlt2" in history_str)
             else (False, "請在回合末將 dlt2 矩陣累加回 gd65 結算！")
         )),

        ("9-9-5", "挑戰題", "擴散前後全圖總人口不變驗證", 6, (),
         lambda g: (
             (True, "總人口守恆驗證正確！")
             if ("sum" in history_str and "==" in history_str and "gd66" in history_str)
             else (False, "請驗證擴散前後全圖人口總數保持一致！")
         )),

        # ----------------------------------------------------------------------
        # 9-9-6 APCS f313 人口遷移：多回合動態擴散模擬實戰 (共 16 分: 5 + 6 + 5)
        # ----------------------------------------------------------------------
        ("9-9-6", "填空題", "APCS f313 排除 -1 城市尋找極值", 5, (),
         lambda g: (
             (True, "排除 -1 城市極值統計填空正確！")
             if ("grid[r][c] != -1" in history_str or "grid[r][c]!=-1" in history_clean or
                 "cell_val != -1" in history_str or "cell_val!=-1" in history_clean)
             else (False, "請在 9-9-6 填空題填入 cell_val != -1，排除 -1 障礙城市！")
         )),

        ("9-9-6", "練習題", "APCS f313 模擬 m 回合後輸出最大與最小人口", 6, (),
         lambda g: (
             (True, "APCS f313 多回合人口遷移模擬正確！")
             if ("for _ in range(m)" in history_str or "for round in range(m)" in history_str) and "delta" in history_str
             else (False, "請執行 m 回合人口遷移模擬並輸出最大與最小城市人口！")
         )),

        ("9-9-6", "挑戰題", "APCS f313 完整實戰通關輸出 min 與 max", 5, (),
         lambda g: (
             (True, "APCS f313 最終通關正確！")
             if ("min(" in history_str and "max(" in history_str) or ("min_val099" in history_str and "max_val099" in history_str)
             else (False, "請輸出模擬後的最小與最大人口！")
         ))    ]

    pass_count = 0
    item_results = []
    item_outputs = []

    for uid, qtype, name, pts, watch, checker in test_cases:
        try:
            ok, msg = checker(env)
        except Exception:
            ok, msg = False, "執行檢驗時發生異常，請確認程式碼是否可正常執行"

        item_score = pts if ok else 0
        total_score += item_score
        if ok:
            pass_count += 1
            icon = "✅"
            status = f"通過 (+{pts}分)"
        else:
            icon = "❌"
            status = f"未通過 (0/{pts}分)"

        out_lines = [f"{icon} [{uid} {qtype}] {_pad(name, 44)} ➔ {status}"]
        if not ok:
            out_lines.append(f"   💡 提示：{msg}")
        item_outputs.append(out_lines)

        item_results.append({
            "uid": uid,
            "type": qtype,
            "name": name,
            "passed": ok,
            "score": item_score,
            "max_score": pts,
            "message": msg,
            "student_value": _student_value(env, watch)
        })

    if total_score >= 90:
        badge = '🏆 完美滿分！你已經徹底攻克二維陣列核心技術，具備 APCS 實戰高手水準！'
    elif total_score >= 80:
        badge = '🌟 優秀！觀念掌握非常扎實，稍微細心檢查即可登峰造極！'
    elif total_score >= 60:
        badge = '👍 及格！基本概念已建立，建議複習未通過的題目加強熟悉度！'
    else:
        badge = '💪 請再接再厲！建議回到上方微型階梯逐題操作並執行程式碼！'

    print("=" * 72)
    print(" 📊 《PythAPCS123》單元 9-9：網格防護與動態模擬：哨兵加框與雙矩陣快照（APCS f313 專題） —— 自動評分報告")
    print("=" * 72)
    print(f" 📈 本單元實作測驗總得分：{total_score} / {max_score} 分（通過題數：{pass_count} / {len(test_cases)} 題）")
    print(f" 🎖️ 獲得榮譽等級：{badge}")
    print("=" * 72)
    print(f" 👤 學員姓名：{declared_name}")
    print(f" 🆔 學號座號：{declared_id}")
    if google_email:
        print(f" 🔑 Google 帳號認證：{google_email}（暱稱：{final_google_name}）")
    elif not is_colab:
        print(f" 💻 執行環境：本機環境（免登入自評）")
    else:
        print(f" 📧 登記信箱：{final_email}")
    print(f" ⏰ 送交時間：{timestamp_str}")
    print("=" * 72)
    print(" 📝 題目作答細項檢驗：")
    for lines in item_outputs:
        for line in lines:
            print(line)
    print("=" * 72)

    # 試算表姓名、學號用學生輸入原值。暱稱與 email 在本機填「本機測試」。
    if google_email:
        sheet_google_name = google_name if google_name else declared_name
        sheet_google_email = google_email
    elif not is_colab:
        sheet_google_name = "本機測試"
        sheet_google_email = "本機測試"
    else:
        sheet_google_name = "未認證"
        sheet_google_email = "未認證"

    score_fingerprint = ",".join(
        f"{item['uid']}:{item['type']}:{'1' if item['passed'] else '0'}"
        for item in item_results
    )

    # --------------------------------------------------------------------------
    # 📡 雲端後台成績記錄（Google Apps Script 試算表 Webhook）
    # 欄位拆開送出。相同成績是否寫入由 Apps Script 判斷，這裡只讀回應。
    # 鐵律：絕不產生任何本地日誌暫存檔。
    # --------------------------------------------------------------------------
    log_data = {
        "unit": "9-9",
        "unit_title": "網格防護與動態模擬：哨兵加框與雙矩陣快照（APCS f313 專題）",
        "declared_name": declared_name,
        "declared_id": declared_id,
        "google_name": sheet_google_name,
        "google_email": sheet_google_email,
        "student_name": declared_name,
        "student_id": declared_id,
        "name": declared_name,
        "id": declared_id,
        "student_email": sheet_google_email,
        "email": sheet_google_email,
        "timestamp": timestamp_str,
        "total_score": total_score,
        "max_score": max_score,
        "pass_count": pass_count,
        "total_count": len(test_cases),
        "badge": badge,
        "details": item_results,
        "grader_version": GRADER_VERSION,
        "grader_source": os.environ.get("GRADER_SOURCE", "").strip() or "web/graders/grade_9_9.py",
        "notebook_file": NOTEBOOK_FILE,
        "score_fingerprint": score_fingerprint
    }

    if LOG_WEBHOOK_URL:
        try:
            req_data = json.dumps(log_data, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(
                LOG_WEBHOOK_URL,
                data=req_data,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                raw_body = response.read().decode("utf-8", errors="replace").strip()
            status = ""
            if raw_body:
                try:
                    payload = json.loads(raw_body)
                    if isinstance(payload, dict):
                        status = str(payload.get("status", "")).strip().lower()
                except json.JSONDecodeError:
                    status = ""
            if status == "duplicate":
                print("📡 [雲端回報] 成績與上次相同，未重複登錄（本機成績仍有效）。\n")
            else:
                print("📡 [雲端回報] 成績已成功上傳並登錄至授課試算表！\n")
        except Exception:
            # 離線測試或連線逾時溫和提示，絕不噴出紅色例外
            if not is_colab:
                print("📡 [本機模式] 成績已於本機評分完成（雲端試算表未連線）。\n")
            else:
                print("📡 [離線模式] 暫時無法連線至雲端試算表，但本機評分已完成。\n")

    if total_score < 100:
        print("\n💡 小技巧：若有題目顯示 ❌ 未通過，請回到上方對應題目的儲存格修改程式碼，")
        print("   並務必重新點擊該題的『▶ 播放鍵』執行，再回來執行此評分儲存格就可以刷新成績與紀錄囉！")
        print("=" * 72)


# 執行評分
auto_grade_unit_9_9()
